https://codereview.stackexchange.com/questions/139235/vigen%C3%A8re-cipher-in-python
while True:
    choice = raw_input("Enter 'e' to encrypt,\nEnter 'd' to decrypt.\n\n")

    if choice.lower() == 'e':
        system('cls')

        key = list(raw_input("Enter an encryption key here:\n"))
        clearText = list(raw_input("\nEnter the text to be encrypted here:\n"))
        system('cls')

        cryptText = crypt(key,clearText)
        cryptDir = open("C:\Users\Yorick\Desktop\cryptText.txt",'w')
        cryptDir.write(cryptText)
        cryptDir.close()
        print("Encryption finished.\nResult saved to desktop.\nPress enter to close the program.")
        _=raw_input('')
        break


    elif choice.lower() == 'd':
        system('cls')        
        key = list(raw_input("Enter a decryption key here:\n"))

        #try opening encrypted txt file
        try:
            cryptDir = open("C:\Users\Yorick\Desktop\cryptText.txt",'r')
            cryptText = list(cryptDir.read())
            cryptDir.close()
        except IOError:
            print("No cryptText.txt found on desktop.")

        clearText = decrypt(key,cryptText)
        print(clearText)
        _=raw_input("\n\n\n\nPress enter to close.")
        break