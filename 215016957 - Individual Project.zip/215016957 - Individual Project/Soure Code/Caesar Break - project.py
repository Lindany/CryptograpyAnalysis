
#215016957 Lindani Ricardo Mabaso
#Project Assignment (Breaking Caesar Message)

import pyperclip, detectEnglish
from tkinter import *
from tkinter.filedialog import askopenfilename #ser Interface to select textfile

def getCypherPosition(symbol,cypher):
    """This function gets the symbol and the cypher domain text
    to be used to encrypt/decrypt the message, and return the position 
    of the symbol if it exist or else -1 if it does not"""
    pos = 0
    for cy_text in cypher:
        if (cy_text==symbol):
            return pos
        pos+=1
    return -1

def getNewLetter(symbol,key):
    """This function uses the getCypherPosition() function to return a new text shifted by the key
    in the cypertext given, to be translated in the main message."""    
    cypher = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !?:;,.-()"
    n = getCypherPosition(symbol,cypher)
    
    if n>0:
        return cypher[(n+key)%72]
    return symbol


def getTranslatedMessage(mode, message, key):
    """get receives mode(encrypt/decrypt) and message(plainText/cypher) and key, for 
    number of shift and return the desired output"""        
    
    if mode[0] == 'd':
        key = -key
    translated = ''
    for symbol in message:
        translated += getNewLetter(symbol,key)
        
    return translated


def Break_Caesar_Message():
    
    #Select TextFile containing the message
    Tk().withdraw() # we don't want a full GUI, so keep the root window from appearing
    filename = askopenfilename(initialdir="...\215016957 - Individual Project\Soure Code\Files",filetypes =(("Text File", "*.txt"),("All Files","*.*")),title = "Choose a file.")
    print (filename)# show an "Open" dialog box and return the path to the selected file
    try:
        
        f_reader =open(filename,"r")
        message = f_reader.read()
        f_reader.close()
        
        #key = 14
        
        #Write To textfile
        f_writer = open("Files\Caesar Boken.txt","w")
        line = "\n215016957 Breaking Caesar\n\nMessage To Break:\n"+message
        
        for key in range(1,72):
            brokenText = getTranslatedMessage("d", message, key)
            if detectEnglish.isEnglish(brokenText): #The only outputted or displayed message is the one with contains english words making sense 
                line += "\n\nKey = "+str(key)+"\nMessage Broken:\n"+str(brokenText)
                pyperclip.copy(getTranslatedMessage("d", message, key)) #copied to clipboard
                break;
        
        f_writer.write(line)
        f_writer.close()    
        print(line)
        
    except:
        print("No file was selected")


Break_Caesar_Message()
