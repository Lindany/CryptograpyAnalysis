#215016957 - Vingener Cipher
import pyperclip
from tkinter import *
from tkinter.filedialog import askopenfilename #ser Interface to select textfile

def VigenereEncyptDecryption():
    try:
        Tk().withdraw() # we don't want a full GUI, so keep the root window from appearing
        filename = askopenfilename(initialdir="...\215016957 - Individual Project\Soure Code\Files",filetypes =(("Text File", "*.txt"),("All Files","*.*")),title = "Choose a file.")
        if not(filename[len(filename)-14:]=="decryption.txt" or filename[len(filename)-14:]=="Encryption.txt"):
            print("""Please select the correct textfile, i.e "Encryption" or "Vigenere_decryption" from files """)
        else:
            fr = open(filename,"r")
            ciphertext = fr.read()
            fr.close()
            message = ciphertext.upper()
            key=""
            line=""
            if filename[len(filename)-14:]=="decryption.txt":
                line = "\n215016957\nVingenere Message To Decrypt:\n"+str(ciphertext) 
                key = "Neuschwanstein"
                Mode = 'decrypt' # set to 'encrypt' or 'decrypt'  
            else:
                line = "\n215016957\nVingenere Message To Encrypt:\n"+str(ciphertext) 
                key = "Lindani"
                Mode = 'encrypt' # set to 'encrypt' or 'decrypt'                 
            line += "\nKey = "+key
            if Mode[0] == 'e':
                translated = encryptMessage(key, message)
            elif Mode[0] == 'd':
                translated = decryptMessage(key, message)
           
            line+= "\n"+str('%sed message:' % (Mode.title()))
            line+= "\n"+str(translated)
            print(line)     
            pyperclip.copy(translated)
            print('\nThe message has been copied to the clipboard.')            
    except:
        print("No file was selected")


def encryptMessage(key, message):
    """Used to encrypt the message"""
    return translateMessage(key, message, 'encrypt')


def decryptMessage(key, message):
    """Used to dencrypt the message"""
    return translateMessage(key, message, 'decrypt')


def translateMessage(key, message, mode):
    """Used to accomodate both encryption and decryption"""
    LETTERS = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'
    translated = [] # stores the encrypted/decrypted message string
    keyIndex = 0
    key = key.upper()
    
    for symbol in message: # loop through each character in message
        num = LETTERS.find(symbol.upper())
        if num != -1: # -1 means symbol.upper() was not found in LETTERS
            if mode[0] == 'e':
                num += LETTERS.find(key[keyIndex]) # add if encrypting
            elif mode[0] == 'd':
                num -= LETTERS.find(key[keyIndex]) # subtract if decrypting

            num %= len(LETTERS) # handle the potential wrap-around

            # add the encrypted/decrypted symbol to the end of translated.
            if symbol.isupper():
                translated.append(LETTERS[num])
            elif symbol.islower():
                translated.append(LETTERS[num].lower())

            keyIndex += 1 # move to the next letter in the key
            if keyIndex == len(key):
                    keyIndex = 0
        else:
            # The symbol was not in LETTERS, so add it to translated as is.
            translated.append(symbol)
            
    return ''.join(translated)

VigenereEncyptDecryption()