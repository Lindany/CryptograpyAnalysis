
#215016957 Lindani Ricardo Mabaso
#Project Assignment (Encryption and Decryption Caesar Message)

import pyperclip, detectEnglish
from tkinter import *
from tkinter.filedialog import askopenfilename #ser Interface to select textfile

def getCypherPosition(symbol,cypher):
    """This function gets the symbol and the cypher domain text
    to be used to encrypt/decrypt the message, and return the position 
    of the symbol if it exist or else -1 if it does not"""
    pos = 0
    for cy_text in cypher:
        if (cy_text==symbol):
            return pos
        pos+=1
    return -1

def getNewLetter(symbol,key):
    """This function uses the getCypherPosition() function to return a new text shifted by the key
    in the cypertext given, to be translated in the main message."""    
    cypher = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz1234567890 !?:;,.-()"
    n = getCypherPosition(symbol,cypher)
    
    if n>0:
        return cypher[(n+key)%72]
    return symbol


def getTranslatedMessage(mode, message, key):
    """get receives mode(encrypt/decrypt) and message(plainText/cypher) and key, for 
    number of shift and return the desired output"""        
    
    if mode[0] == 'd':
        key = -key
    translated = ''
    for symbol in message:
        translated += getNewLetter(symbol,key)
        
    return translated


def En_Dencrypt_Caesar_Message():
    
    #Read File from Textfile 
    try:
        Tk().withdraw() # we don't want a full GUI, so keep the root window from appearing
        filename = askopenfilename(initialdir="...\215016957 - Individual Project\Soure Code\Files",filetypes =(("Text File", "*.txt"),("All Files","*.*")),title = "Choose a file.")
        print (filename[len(filename)-14:])# show an "Open" dialog box and return the path to the selected file
        if not(filename[len(filename)-14:]=="decryption.txt" or filename[len(filename)-14:]=="Encryption.txt"):
            print("""Please select the correct textfile, i.e "Encryption.txt" or "Casear_decryption.txt" from files """)
        else:
            f_reader =open(filename,"r")
            message = f_reader.read()
            f_reader.close()
            if filename[len(filename)-14:]=="decryption.txt": #Decryption
                key = 14 #Default given key = 14
                #Write To textfile (Decrypted)
                f_writer = open("Files\ 215016957 Decrypt.txt","w")
                line = "\n215016957 Dencryption Caesar\n\nMessage To Decrypt:\n"+message
                line += "\n\nKey = "+str(key)+"\nMessage Decrypted:\n"+str( getTranslatedMessage("d", message, key))
                pyperclip.copy(getTranslatedMessage("d", message, key)) #copied to clipboard
                
            else:                                     #Ecryption
                key = 17  #Default given key (10 + 7) 10 + last digit of student number
                #Write To textfile (Encrypted)
                f_writer = open("Files\ 215016957 Encrypt.txt","w")
                line = "\n215016957 Encryption Caesar\n\nMessage To Encrypt:\n"+message
                line += "\n\nKey = "+str(key)+"\nMessage Encrypted:\n"+str( getTranslatedMessage("e", message, key))
                pyperclip.copy(getTranslatedMessage("e", message, key)) #copied to clipboard
            
            f_writer.write(line)
            f_writer.close()    
            print(line)
    except:
        print("No file was selected")

En_Dencrypt_Caesar_Message()
